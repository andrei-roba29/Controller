const C = "padlink-v1", FILES = ["/", "/manifest.json", "/icon-192.png"];
self.addEventListener("install", e => e.waitUntil(caches.open(C).then(c => c.addAll(FILES))));
self.addEventListener("fetch", e => {
  if (e.request.url.includes("/ws")) return;
  e.respondWith(fetch(e.request).catch(() => caches.match(e.request)));
});
