# PadLink

Use your phone as a PS4 (DualShock 4) controller on a Windows PC.

## PC setup (once)
1. Install Python 3.10+.
2. `pip install -r requirements.txt` (installing vgamepad also sets up the ViGEmBus driver; accept the prompt).
3. `python server.py`

The console prints a URL and a 6-digit PIN.

## Phone
1. Connect the phone to the same Wi-Fi as the PC.
2. Open the printed URL, enter the PIN, tap Connect.
3. Rotate to landscape. Windows and games now see a DualShock 4.

## Install as an app (PWA)
Browsers only offer "Install app" on HTTPS. Two options:
- Run `python server.py --cert cert.pem --key key.pem` (make a cert with mkcert, then trust it on the phone), or
- Reach the server through a tunnel with HTTPS (Tailscale Serve, Cloudflare Tunnel). This also lets you play away from home.
Without HTTPS the controller still works in the browser, and "Add to Home Screen" works as a bookmark.

## Notes
- Windows firewall: allow Python on private networks when prompted.
- Triggers are digital (full press). Gyro, touchpad swipes and rumble are not included.
- Anyone with the PIN can control the PC pad, so keep the server on trusted networks.
