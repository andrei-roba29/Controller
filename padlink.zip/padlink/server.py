"""PadLink companion server (Windows).
Serves the phone PWA and turns its touch input into a virtual DualShock 4.
Requires the ViGEmBus driver (installed together with vgamepad's installer prompt)."""
import argparse, asyncio, json, secrets, socket, ssl
from pathlib import Path
from aiohttp import web, WSMsgType
import vgamepad as vg

B, S, D = vg.DS4_BUTTONS, vg.DS4_SPECIAL_BUTTONS, vg.DS4_DPAD_DIRECTIONS
BUTTONS = {
    "cross": B.DS4_BUTTON_CROSS, "circle": B.DS4_BUTTON_CIRCLE,
    "square": B.DS4_BUTTON_SQUARE, "triangle": B.DS4_BUTTON_TRIANGLE,
    "l1": B.DS4_BUTTON_SHOULDER_LEFT, "r1": B.DS4_BUTTON_SHOULDER_RIGHT,
    "l2": B.DS4_BUTTON_TRIGGER_LEFT, "r2": B.DS4_BUTTON_TRIGGER_RIGHT,
    "share": B.DS4_BUTTON_SHARE, "options": B.DS4_BUTTON_OPTIONS,
    "l3": B.DS4_BUTTON_THUMB_LEFT, "r3": B.DS4_BUTTON_THUMB_RIGHT,
}
SPECIAL = {"ps": S.DS4_SPECIAL_BUTTON_PS, "touchpad": S.DS4_SPECIAL_BUTTON_TOUCHPAD}
DPAD = {
    frozenset(): D.DS4_BUTTON_DPAD_NONE,
    frozenset({"up"}): D.DS4_BUTTON_DPAD_NORTH,
    frozenset({"up", "right"}): D.DS4_BUTTON_DPAD_NORTHEAST,
    frozenset({"right"}): D.DS4_BUTTON_DPAD_EAST,
    frozenset({"down", "right"}): D.DS4_BUTTON_DPAD_SOUTHEAST,
    frozenset({"down"}): D.DS4_BUTTON_DPAD_SOUTH,
    frozenset({"down", "left"}): D.DS4_BUTTON_DPAD_SOUTHWEST,
    frozenset({"left"}): D.DS4_BUTTON_DPAD_WEST,
    frozenset({"up", "left"}): D.DS4_BUTTON_DPAD_NORTHWEST,
}
clamp = lambda v: max(0, min(255, int(v)))

def apply(pad, msg):
    held = set(msg.get("b", []))
    for name, btn in BUTTONS.items():
        (pad.press_button if name in held else pad.release_button)(button=btn)
    for name, btn in SPECIAL.items():
        (pad.press_special_button if name in held else pad.release_special_button)(special_button=btn)
    pad.directional_pad(direction=DPAD.get(frozenset(held & {"up", "down", "left", "right"}), D.DS4_BUTTON_DPAD_NONE))
    pad.left_trigger(value=255 if "l2" in held else 0)
    pad.right_trigger(value=255 if "r2" in held else 0)
    pad.left_joystick(x_value=clamp(msg.get("lx", 128)), y_value=clamp(msg.get("ly", 128)))
    pad.right_joystick(x_value=clamp(msg.get("rx", 128)), y_value=clamp(msg.get("ry", 128)))
    pad.update()

HOST_PAGE = """<!doctype html><meta charset=utf-8><title>PadLink</title>
<body style="font-family:system-ui;background:#16181f;color:#e8eaf0;text-align:center;padding:40px">
<h1>PadLink</h1><p>On your phone (same Wi-Fi), scan the code or open:</p>
<p style="font-size:22px">{url}</p><div id=qr style="background:#fff;display:inline-block;padding:12px;border-radius:8px"></div>
<p>Pairing PIN</p><p style="font:700 56px ui-monospace,monospace;letter-spacing:.2em;margin:0">{pin}</p>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script>try{{new QRCode(document.getElementById("qr"),{{text:"{url}#{pin}",width:200,height:200}})}}catch(e){{document.getElementById("qr").remove()}}</script>"""

def local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1)); return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--cert"); ap.add_argument("--key")
    a = ap.parse_args()
    pin = f"{secrets.randbelow(10**6):06d}"
    scheme = "https" if (a.cert and a.key) else "http"
    url = f"{scheme}://{local_ip()}:{a.port}"
    print("\n==============================", flush=True)
    print(f"  Open on your phone: {url}", flush=True)
    print(f"  Pairing PIN:        {pin}", flush=True)
    print(f"  Or open on this PC: {scheme}://localhost:{a.port}/host", flush=True)
    print("==============================\n", flush=True)
    try:
        pad = vg.VDS4Gamepad()
    except Exception as e:
        print("Could not create the virtual controller:", e, flush=True)
        print("Install the ViGEmBus driver: https://github.com/nefarius/ViGEmBus/releases", flush=True)
        input("Press Enter to close...")
        return
    active = {"ws": None}

    async def ws_handler(req):
        ws = web.WebSocketResponse(heartbeat=10)
        await ws.prepare(req)
        if not secrets.compare_digest(req.query.get("pin", ""), pin):
            await ws.close(code=4001, message=b"bad pin"); return ws
        if active["ws"] and not active["ws"].closed:
            await active["ws"].close(code=4002, message=b"replaced")
        active["ws"] = ws
        print("Phone connected:", req.remote, flush=True)
        try:
            async for m in ws:
                if m.type == WSMsgType.TEXT:
                    apply(pad, json.loads(m.data))
        finally:
            if active["ws"] is ws:
                apply(pad, {})
                print("Phone disconnected", flush=True)
        return ws

    async def host(req):
        if req.remote not in ("127.0.0.1", "::1"):
            raise web.HTTPForbidden()
        return web.Response(text=HOST_PAGE.format(url=url, pin=pin), content_type="text/html")

    web_dir = Path(__file__).parent / "web"
    app = web.Application()
    app.add_routes([web.get("/ws", ws_handler), web.get("/host", host),
                    web.get("/", lambda r: web.FileResponse(web_dir / "index.html"))])
    app.router.add_static("/", web_dir)
    ctx = None
    if a.cert and a.key:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); ctx.load_cert_chain(a.cert, a.key)
    try:
        web.run_app(app, port=a.port, ssl_context=ctx, print=None)
    except OSError as e:
        print("Could not start the server:", e, flush=True)
        input("Press Enter to close...")

if __name__ == "__main__":
    main()
